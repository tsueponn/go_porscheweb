package main

import (
	"database/sql"
	"fmt"
	"html/template"
	"log"
	"net/http"
	"strconv"

	"golang.org/x/crypto/bcrypt"

	_ "github.com/go-sql-driver/mysql"
)

// Определение структур и чтобы не путаться
type User struct {
	ID       int
	Username string
	Email    string
	Age      int
}

type Product struct {
	ID          int
	Name        string
	Description string
	Price       float64
	ImageURL    string
}

type CartItem struct {
	ProductID int
	Name      string
	Price     float64
	Quantity  int
}

type Promotion struct {
	ID          int
	Name        string
	Description string
	Discount    float64
}

// важная переменная для хранения подключения к базе данных
var db *sql.DB

// хом пейдж
func homePageHandler(w http.ResponseWriter, r *http.Request) {
	tmpl, _ := template.ParseFiles("templates/index.html")
	tmpl.Execute(w, nil)
}

// Регистрация
func registerHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodPost {
		username := r.FormValue("username")
		password := r.FormValue("password")
		email := r.FormValue("email")
		age, _ := strconv.Atoi(r.FormValue("age"))

		hashedPassword, _ := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)

		_, err := db.Exec("INSERT INTO users (username, password_hash, email, age) VALUES (?, ?, ?, ?)", username, hashedPassword, email, age)
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}

		http.Redirect(w, r, "/login", http.StatusSeeOther)
		return
	}

	tmpl, _ := template.ParseFiles("templates/register.html")
	tmpl.Execute(w, nil)
}

// Логин
func loginHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodPost {
		username := r.FormValue("username")
		password := r.FormValue("password")

		var hashedPassword string
		err := db.QueryRow("SELECT password_hash FROM users WHERE username = ?", username).Scan(&hashedPassword)
		if err != nil {
			http.Error(w, "Invalid username or password", http.StatusUnauthorized)
			return
		}

		err = bcrypt.CompareHashAndPassword([]byte(hashedPassword), []byte(password))
		if err != nil {
			http.Error(w, "Invalid username or password", http.StatusUnauthorized)
			return
		}

		http.Redirect(w, r, "/", http.StatusSeeOther)
		return
	}

	tmpl, _ := template.ParseFiles("templates/login.html")
	tmpl.Execute(w, nil)
}

// каталог товаров
func catalogHandler(w http.ResponseWriter, r *http.Request) {
	products, err := getProducts(db)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	tmpl, _ := template.ParseFiles("templates/product.html")
	tmpl.Execute(w, products)
}

func getProducts(db *sql.DB) ([]Product, error) {
	rows, err := db.Query("SELECT id, name, description, price, image_url FROM products")
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var products []Product
	for rows.Next() {
		var p Product
		err := rows.Scan(&p.ID, &p.Name, &p.Description, &p.Price, &p.ImageURL)
		if err != nil {
			return nil, err
		}
		products = append(products, p)
	}
	return products, nil
}

// корзина товаров
func cartHandler(w http.ResponseWriter, r *http.Request) {
	userID := getUserIDFromSession(r)
	cartItems, err := getCartItems(db, userID)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	tmpl, _ := template.ParseFiles("templates/cart.html")
	tmpl.Execute(w, cartItems)
}

func getCartItems(db *sql.DB, userID int) ([]CartItem, error) {
	rows, err := db.Query("SELECT p.id, p.name, p.price, c.quantity FROM carts c JOIN products p ON c.product_id = p.id WHERE c.user_id = ?", userID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var cartItems []CartItem
	for rows.Next() {
		var ci CartItem
		err := rows.Scan(&ci.ProductID, &ci.Name, &ci.Price, &ci.Quantity)
		if err != nil {
			return nil, err
		}
		cartItems = append(cartItems, ci)
	}
	return cartItems, nil
}

func addToCartHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodPost {
		userID := getUserIDFromSession(r)
		productID, _ := strconv.Atoi(r.FormValue("product_id"))
		quantity, _ := strconv.Atoi(r.FormValue("quantity"))

		_, err := db.Exec("INSERT INTO carts (user_id, product_id, quantity) VALUES (?, ?, ?)", userID, productID, quantity)
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}

		http.Redirect(w, r, "/cart", http.StatusSeeOther)
	}
}

// подверждение покупки
func confirmPurchaseHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodPost {
		userID := getUserIDFromSession(r)

		_, err := db.Exec("INSERT INTO orders (user_id, product_id, quantity) SELECT user_id, product_id, quantity FROM carts WHERE user_id = ?", userID)
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}

		_, err = db.Exec("DELETE FROM carts WHERE user_id = ?", userID)
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}

		http.Redirect(w, r, "/orders", http.StatusSeeOther)
	}
}

// рейтинг систем
func addRatingHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodPost {
		userID := getUserIDFromSession(r)
		productID, _ := strconv.Atoi(r.FormValue("product_id"))
		rating, _ := strconv.Atoi(r.FormValue("rating"))

		_, err := db.Exec("INSERT INTO ratings (user_id, product_id, rating) VALUES (?, ?, ?)", userID, productID, rating)
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}

		http.Redirect(w, r, "/product?id="+r.FormValue("product_id"), http.StatusSeeOther)
	}
}

// бд - отзывы
func addReviewHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method == http.MethodPost {
		userID := getUserIDFromSession(r)
		productID, _ := strconv.Atoi(r.FormValue("product_id"))
		review := r.FormValue("review")

		_, err := db.Exec("INSERT INTO reviews (user_id, product_id, review) VALUES (?, ?, ?)", userID, productID, review)
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}

		http.Redirect(w, r, "/product?id="+r.FormValue("product_id"), http.StatusSeeOther)
	}
}

// система поиска (сёрджж)
func searchHandler(w http.ResponseWriter, r *http.Request) {
	query := r.URL.Query().Get("q")
	products, err := searchProducts(db, query)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	tmpl, _ := template.ParseFiles("templates/search.html")
	tmpl.Execute(w, products)
}

func searchProducts(db *sql.DB, query string) ([]Product, error) {
	rows, err := db.Query("SELECT id, name, description, price, image_url FROM products WHERE name LIKE ?", "%"+query+"%")
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var products []Product
	for rows.Next() {
		var p Product
		err := rows.Scan(&p.ID, &p.Name, &p.Description, &p.Price, &p.ImageURL)
		if err != nil {
			return nil, err
		}
		products = append(products, p)
	}
	return products, nil
}

// система сезонных акций
func promotionsHandler(w http.ResponseWriter, r *http.Request) {
	promotions, err := getPromotions(db)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	tmpl, _ := template.ParseFiles("templates/promotions.html")
	tmpl.Execute(w, promotions)
}

func getPromotions(db *sql.DB) ([]Promotion, error) {
	rows, err := db.Query("SELECT id, name, description, discount FROM promotions")
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var promotions []Promotion
	for rows.Next() {
		var p Promotion
		err := rows.Scan(&p.ID, &p.Name, &p.Description, &p.Discount)
		if err != nil {
			return nil, err
		}
		promotions = append(promotions, p)
	}
	return promotions, nil
}

// вспомогательные функции
func getUserIDFromSession(r *http.Request) int {
	// здесь должна быть логика получения ID пользователя из сессии
	return 1 // временно возвращаем ID 1 для тестирования
}

func main() {
	var err error
	dsn := "root:@tcp(127.0.0.1:3306)/golang"
	db, err = sql.Open("mysql", dsn)
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()

	err = db.Ping()
	if err != nil {
		log.Fatal(err)
	}

	fmt.Println("Connected to MySQL")

	http.HandleFunc("/", homePageHandler)
	http.HandleFunc("/register", registerHandler)
	http.HandleFunc("/login", loginHandler)
	http.HandleFunc("/product", catalogHandler)
	http.HandleFunc("/cart", cartHandler)
	http.HandleFunc("/add-to-cart", addToCartHandler)
	http.HandleFunc("/confirm-purchase", confirmPurchaseHandler)
	http.HandleFunc("/add-rating", addRatingHandler)
	http.HandleFunc("/add-review", addReviewHandler)
	http.HandleFunc("/search", searchHandler)
	http.HandleFunc("/promotions", promotionsHandler)

	http.ListenAndServe(":8080", nil)
}
