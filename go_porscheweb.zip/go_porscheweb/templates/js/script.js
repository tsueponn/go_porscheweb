
function checkLogin() {
  const loginInput = document.getElementById('email');
  const errorText = document.getElementById('emailError');
  if (loginInput.value !== '') {
      const atIndex = loginInput.value.indexOf('@');
      const dotIndex = loginInput.value.lastIndexOf('.');
      if (atIndex < 1  dotIndex < atIndex + 2  dotIndex + 1 >= loginInput.value.length) {
      errorText.textContent = 'Invalid login';
      return false;
      } else {
      errorText.textContent = '';
      return true;
      }
  } else {
      errorText.textContent = '';
      return false;
  }
}


var passwordRegex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[0-9a-zA-Z]{8,}$/;

document.getElementById("myForm").addEventListener("submit", function(event) {
  var passwordInput = document.getElementById("password");

  // Проверяем, что пароль содержит не менее 8 символов
  if (passwordInput.value.length < 8) {
    alert("Пароль должен содержать не менее 8 символов.");
    event.preventDefault();
    return;
  }

  // Проверяем, что пароль содержит цифру, букву в верхнем регистре и букву в нижнем регистре
  var passwordRegex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[0-9a-zA-Z]{8,}$/;
  if (!passwordRegex.test(passwordInput.value)) {
    alert("Ваш пароль недостаточно надежен.");
    event.preventDefault();
    return;
  }

  // ...код для проверки email...

  // Если все проверки пройдены успешно, перенаправляем пользователя на страницу "welcome.html"
  window.location.href = "welcome.html";

  // Останавливаем отправку формы на сервер
  event.preventDefault();
});

